package com.android.register;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class disp_information extends AppCompatActivity {

    TextView name,phone,gender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disp_information);

        name = findViewById(R.id.disp_name);
        phone = findViewById(R.id.disp_phone);
        gender = findViewById(R.id.disp_gender);


        Intent i = getIntent();
        name.setText(i.getStringExtra("name"));
        phone.setText(i.getStringExtra("phone"));
        gender.setText(i.getStringExtra("gender"));

    }
}