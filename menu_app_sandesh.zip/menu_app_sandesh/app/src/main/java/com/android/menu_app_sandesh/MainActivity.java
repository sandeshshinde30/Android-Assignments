package com.android.menu_app_sandesh;

import android.os.Bundle;
import android.util.TypedValue;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
//    TextView textView = findViewById(R.id.textView);
    Button DP15,DP20,DP25,DP30,DP35,DP40;
    EditText text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        text = findViewById(R.id.text);
        DP15 = findViewById(R.id.DP15);
        DP20 = findViewById(R.id.DP20);
        DP25 = findViewById(R.id.DP25);
        DP30 = findViewById(R.id.DP30);
        DP35 = findViewById(R.id.DP35);
        DP40 = findViewById(R.id.DP40);


        DP15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text.setTextSize(15);
            }
        });

        DP20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text.setTextSize(20);
            }
        });

        DP25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text.setTextSize(25);
            }
        });

        DP30.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text.setTextSize(30);
            }
        });

        DP35.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text.setTextSize(35);
            }
        });

        DP40.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text.setTextSize(40);
            }
        });

    }


    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.context_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
//        switch (item.getItemId()) {
////            case R.id.small_text:
////                textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14); // Change text size to small
////                return true;
////            case R.id.medium_text:
////                textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18); // Change text size to medium
////                return true;
////            case R.id.large_text:
////                textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24); // Change text size to large
////                return true;
////            default:
////                return super.onContextItemSelected(item);
//        }
        return true;
    }

}


