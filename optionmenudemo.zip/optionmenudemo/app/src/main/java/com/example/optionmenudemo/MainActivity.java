package com.example.optionmenudemo;

import android.content.ClipData;
import android.content.Intent;
import android.media.RouteListingPreference;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    MenuItem i1,i2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
         i1 = menu.findItem(R.id.item1);
         i2 = menu.findItem(R.id.item2);
        MenuInflater i = getMenuInflater();
        i.inflate(R.menu.main_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected( MenuItem item) {
        int id = item.getItemId();

        if(id==R.id.item1){
            Intent i = new Intent(getApplicationContext(), About_activity.class);
            startActivity(i);
            Toast.makeText(this, "About selected", Toast.LENGTH_SHORT).show();
        }
        else if (id == R.id.item2)
        {
            Intent i = new Intent(getApplicationContext(), Help_activity.class);
            startActivity(i);
            Toast.makeText(this, "Help selected", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.item3) {
            Intent i = new Intent(getApplicationContext(), Settings_activity.class);
            startActivity(i);
            Toast.makeText(this, "Settings selected", Toast.LENGTH_SHORT).show();
        }

        return super.onOptionsItemSelected(item);
    }
}